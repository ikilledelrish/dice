package application;

import java.util.Random;

public class Controller {

    private final Random random = new Random();

    public void rollDice() {
        setRandomPosition(dice1ImageView);
        setRandomPosition(dice2ImageView);
    }

    private void setRandomPosition(ImageView imageView) {
        double sceneWidth = imageView.getScene().getWidth();
        double sceneHeight = imageView.getScene().getHeight();

        double maxWidth = sceneWidth - imageView.getFitWidth();
        double maxHeight = sceneHeight - imageView.getFitHeight();

        double randomX = random.nextDouble() * maxWidth;
        double randomY = random.nextDouble() * maxHeight;

        imageView.setLayoutX(randomX);
        imageView.setLayoutY(randomY);
    }
}


buldit